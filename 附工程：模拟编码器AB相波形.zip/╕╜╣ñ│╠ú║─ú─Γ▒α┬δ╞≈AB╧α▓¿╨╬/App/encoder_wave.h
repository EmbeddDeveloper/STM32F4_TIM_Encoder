/**
  ******************************************************************************
  * @�ļ���     �� encoder_wave.h
  * @����       �� strongerHuang
  * @�汾       �� V1.0.0
  * @����       �� 2017��11��11��
  * @ժҪ       �� (ģ��)����������ͷ�ļ�
  ******************************************************************************/

/* �����ֹ�ݹ���� ----------------------------------------------------------*/
#ifndef _ENCODER_WAVE_H
#define _ENCODER_WAVE_H

/* ������ͷ�ļ� --------------------------------------------------------------*/
#include "stm32f4xx.h"


/* �궨�� --------------------------------------------------------------------*/
#define ENCODE_A_PIN              GPIO_Pin_6
#define ENCODE_A_GPIO_PORT        GPIOC
#define ENCODE_A_GPIO_CLK         RCC_AHB1Periph_GPIOC

#define ENCODE_B_PIN              GPIO_Pin_7
#define ENCODE_B_GPIO_PORT        GPIOC
#define ENCODE_B_GPIO_CLK         RCC_AHB1Periph_GPIOC

/* ����(�� ��) */
#define ENCODE_A_L()              GPIO_ResetBits(ENCODE_A_GPIO_PORT, ENCODE_A_PIN)
#define ENCODE_A_H()              GPIO_SetBits(ENCODE_A_GPIO_PORT, ENCODE_A_PIN)

#define ENCODE_B_L()              GPIO_ResetBits(ENCODE_B_GPIO_PORT, ENCODE_B_PIN)
#define ENCODE_B_H()              GPIO_SetBits(ENCODE_B_GPIO_PORT, ENCODE_B_PIN)


/* �������� ------------------------------------------------------------------*/
void ENCODER_WAVE_Initializes(void);
void ENCODER_WAVE_Forward(uint16_t Cnt);
void ENCODER_WAVE_Back(uint16_t Cnt);


#endif /* _ENCODER_WAVE_H */

/**** Copyright (C)2017 strongerHuang. All Rights Reserved **** END OF FILE ****/
