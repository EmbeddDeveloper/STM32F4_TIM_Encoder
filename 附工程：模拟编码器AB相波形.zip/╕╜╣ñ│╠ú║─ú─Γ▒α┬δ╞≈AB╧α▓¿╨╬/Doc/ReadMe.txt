一、工程说明
    1、时间：    2017年11月11日
    2、作者：    strongerHuang
    3、开发环境：MDK-ARM V5.24a
    4、标准库：  V1.8.0
    5、工程版本：V1.0.0
    6、目标芯片：STM32F401xx系列芯片

二、提示
    本工程适合于STM32F401xx系列芯片, 包含:
              48Pin        64Pin       100Pin
     128K: STM32F401CB  STM32F401RB  STM32F401VB
     256K: STM32F401CC  STM32F401RC  STM32F401VC
     384K: STM32F401CD  STM32F401RD  STM32F401VD
     512K: STM32F401CE  STM32F401RE  STM32F401VE

    只要没有特别说明，工程都适合以上芯片;
    可根据自己芯片型号选择相应的"工程目标";
    (提示: 若目标选项中没有对应的型号,可自己修改型号，一般这系列芯片,型号不对应,软件也可兼容。
    修改型号:Project -> Options for Target ->Device选择对应型号即可)

三、帮助
    微信搜索公众号：EmbeddDeveloper, 关注, 查看更多精彩内容。
